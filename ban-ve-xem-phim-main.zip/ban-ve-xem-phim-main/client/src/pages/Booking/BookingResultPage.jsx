import { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { CheckCircle, XCircle, Loader2, MapPin, Clock, Film, Armchair, Coffee, Tag, CreditCard, Download, Star } from 'lucide-react';
import { Button, Divider, Modal, Rate, Input, message } from 'antd';
import { requestConfirmMomoReturn, requestConfirmVNPayReturn } from '@/config/PaymentRequest';
import { requestGetBookingById } from '@/config/BookingRequest';
import { requestCreateReview, requestGetMyReviews } from '@/config/ReviewRequest';
import dayjs from 'dayjs';
import QRCode from 'react-qr-code';

export default function BookingResultPage() {
    const [searchParams] = useSearchParams();
    const navigate = useNavigate();
    const [status, setStatus] = useState('loading');
    const [booking, setBooking] = useState(null);
    const [hasReviewed, setHasReviewed] = useState(false);

    // Review state
    const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
    const [reviewRating, setReviewRating] = useState(5);
    const [reviewText, setReviewText] = useState('');
    const [submittingReview, setSubmittingReview] = useState(false);

    useEffect(() => {
        const confirmPayment = async () => {
            const resultCode = searchParams.get('resultCode');
            const extraData = searchParams.get('extraData');
            const vnp_ResponseCode = searchParams.get('vnp_ResponseCode');
            const statusParam = searchParams.get('status');
            const bookingIdParam = searchParams.get('bookingId');

            let resolvedBookingId = bookingIdParam;

            try {
                if (resultCode !== null) {
                    // Redirect từ MOMO
                    if (resultCode === '0') {
                        const allParams = {};
                        searchParams.forEach((value, key) => { allParams[key] = value; });
                        const res = await requestConfirmMomoReturn(allParams);
                        resolvedBookingId = res?.metadata?._id;
                        setStatus('success');
                        // Trigger cập nhật thông báo ngay lập tức
                        setTimeout(() => window.dispatchEvent(new Event('notification:refresh')), 1500);
                    } else {
                        setStatus('failed');
                        return;
                    }
                } else if (vnp_ResponseCode !== null) {
                    // Redirect từ VNPay
                    if (vnp_ResponseCode === '00') {
                        const allParams = {};
                        searchParams.forEach((value, key) => { allParams[key] = value; });
                        const res = await requestConfirmVNPayReturn(allParams);
                        resolvedBookingId = res?.metadata?._id;
                        setStatus('success');
                        // Trigger cập nhật thông báo ngay lập tức
                        setTimeout(() => window.dispatchEvent(new Event('notification:refresh')), 1500);
                    } else {
                        setStatus('failed');
                        return;
                    }
                } else if (statusParam) {
                    if (statusParam === 'success') {
                        setStatus('success');
                    } else {
                        setStatus('failed');
                        return;
                    }
                } else {
                    // Fallback: Momo thành công nhưng server lỗi
                    if (extraData) {
                        try {
                            const decoded = JSON.parse(atob(extraData));
                            resolvedBookingId = decoded.bookingId;
                        } catch (_) {}
                    }
                    setStatus('failed');
                    return;
                }

                // Fetch chi tiết booking nếu có ID
                if (resolvedBookingId) {
                    const bookingRes = await requestGetBookingById(resolvedBookingId);
                    if (bookingRes?.metadata) {
                        setBooking(bookingRes.metadata);
                        // Check review
                        if (bookingRes.metadata.showtimeId?.movieId) {
                            const reviewsRes = await requestGetMyReviews().catch(()=>null);
                            if (reviewsRes?.metadata) {
                                const isRev = reviewsRes.metadata.some(r => r.movieId === bookingRes.metadata.showtimeId.movieId._id);
                                setHasReviewed(isRev);
                            }
                        }
                    }
                }
            } catch (err) {
                console.error('Confirm error:', err);
                // Dù server lỗi, nếu momo/vnpay nói thành công thì vẫn show thành công
                if (resultCode === '0' || vnp_ResponseCode === '00') {
                    setStatus('success');
                    if (extraData) {
                        try {
                            const decoded = JSON.parse(atob(extraData));
                            resolvedBookingId = decoded.bookingId;
                            const bookingRes = await requestGetBookingById(resolvedBookingId);
                            if (bookingRes?.metadata) {
                                setBooking(bookingRes.metadata);
                                if (bookingRes.metadata.showtimeId?.movieId) {
                                    const reviewsRes = await requestGetMyReviews().catch(()=>null);
                                    if (reviewsRes?.metadata) {
                                        const isRev = reviewsRes.metadata.some(r => r.movieId === bookingRes.metadata.showtimeId.movieId._id);
                                        setHasReviewed(isRev);
                                    }
                                }
                            }
                        } catch (_) {}
                    }
                } else {
                    setStatus('failed');
                }
            }
        };

        confirmPayment();
    }, []);

    if (status === 'loading') {
        return (
            <div className="min-h-screen bg-[#050505] flex items-center justify-center">
                <div className="text-center">
                    <Loader2 className="animate-spin text-[#E50914] mx-auto mb-4" size={48} />
                    <p className="text-gray-400 text-lg">Đang xác nhận giao dịch...</p>
                </div>
            </div>
        );
    }

    if (status === 'failed') {
        return (
            <div className="min-h-screen bg-[#050505] flex items-center justify-center px-4">
                <div className="max-w-md w-full text-center">
                    <div className="flex justify-center mb-6">
                        <div className="w-24 h-24 rounded-full bg-red-500/20 flex items-center justify-center">
                            <XCircle className="text-red-500" size={52} />
                        </div>
                    </div>
                    <h1 className="text-3xl font-black text-white mb-3">Thanh toán thất bại</h1>
                    <p className="text-gray-400 mb-8">Giao dịch bị hủy hoặc có lỗi xảy ra. Vé của bạn chưa được đặt.</p>
                    <div className="flex gap-3 justify-center">
                        <Button size="large" onClick={() => navigate(-2)}>Thử lại</Button>
                        <Button size="large" onClick={() => navigate('/')}>Về trang chủ</Button>
                    </div>
                </div>
            </div>
        );
    }

    // ===== SUCCESS =====
    const showtime = booking?.showtimeId;
    const movie = showtime?.movieId;
    const room = showtime?.roomId;
    const cinema = room?.cinemaId;
    const voucher = booking?.voucherId;
    const ticketPrice = (booking?.totalPrice || 0) + (booking?.discountAmount || 0);
    const serviceTotal = booking?.services?.reduce((sum, s) => {
        return sum + (s.serviceId?.price || 0) * (s.quantity || 1);
    }, 0) || 0;

    const payMethodLabel = {
        Momo: (
            <span className="flex items-center gap-2">
                <img src="https://developers.momo.vn/v3/assets/images/MOMO-Logo-App-6262c3743a290ef02396a24ea2b66c35.png" alt="MoMo" className="w-5 h-5 rounded" />
                MoMo
            </span>
        ),
        VNPay: (
            <span className="flex items-center gap-2">
                <img src="https://vnpay.vn/s1/statics.vnpay.vn/2023/6/0oxhzjmxbksr1686814746087.png" alt="VNPay" className="w-5 h-5 object-contain rounded" />
                VNPay
            </span>
        ),
        Cash: <span className="flex items-center gap-2">💵 Tiền mặt tại quầy</span>,
    };

    const handleSubmitReview = async () => {
        if (!reviewRating || !reviewText.trim()) {
            message.warning('Vui lòng chọn số sao và nhập bình luận!');
            return;
        }
        try {
            setSubmittingReview(true);
            await requestCreateReview(movie._id, { rating: reviewRating, comment: reviewText });
            message.success('Cảm ơn bạn đã đánh giá!');
            setHasReviewed(true);
            setIsReviewModalOpen(false);
        } catch (error) {
            message.error(error.message || 'Lỗi khi gửi đánh giá');
        } finally {
            setSubmittingReview(false);
        }
    };

    return (
        <div className="min-h-screen bg-[#050505] pt-24 pb-20 px-4">
            <div className="max-w-2xl mx-auto">
                {/* Header */}
                <div className="text-center mb-8">
                    <div className="flex justify-center mb-4">
                        <div className="w-20 h-20 rounded-full bg-green-500/20 flex items-center justify-center ring-4 ring-green-500/30">
                            <CheckCircle className="text-green-500" size={44} />
                        </div>
                    </div>
                    <h1 className="text-3xl font-black text-white">Đặt vé thành công! 🎉</h1>
                    <p className="text-gray-400 mt-2">Cảm ơn bạn đã sử dụng FlixFlow</p>
                    {booking?._id && (
                        <div className="mt-3 inline-block bg-[#1a1a1a] px-4 py-1.5 rounded-full border border-white/10">
                            <span className="text-gray-500 text-xs">Mã đặt vé:</span>{' '}
                            <span className="text-[#E50914] font-mono font-bold text-sm">{booking._id}</span>
                        </div>
                    )}
                </div>

                {/* Ticket Card */}
                <div className="bg-[#111111] rounded-2xl border border-white/10 overflow-hidden shadow-2xl">
                    {/* Movie Header */}
                    <div className="flex gap-4 p-6 bg-gradient-to-r from-[#1a1a1a] to-[#111111] border-b border-white/5">
                        {movie?.posterUrl && (
                            <img
                                src={`${import.meta.env.VITE_API_URL}${movie.posterUrl}`}
                                alt={movie?.title}
                                className="w-20 h-28 object-cover rounded-lg shrink-0 shadow-lg"
                            />
                        )}
                        <div className="flex flex-col justify-center">
                            <div className="flex items-center gap-2 text-[#E50914] text-xs font-bold uppercase tracking-widest mb-1">
                                <Film size={12} />
                                Vé Xem Phim
                            </div>
                            <h2 className="text-2xl font-black text-white leading-tight">
                                {movie?.title || 'FlixFlow Cinema'}
                            </h2>
                            {cinema && (
                                <div className="flex items-center gap-1.5 mt-2 text-gray-400 text-sm">
                                    <MapPin size={13} />
                                    {cinema.name} — {room?.name}
                                </div>
                            )}
                            {showtime?.startTime && (
                                <div className="flex items-center gap-1.5 mt-1 text-gray-400 text-sm">
                                    <Clock size={13} />
                                    {dayjs(showtime.startTime).format('HH:mm — dddd, DD/MM/YYYY')}
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Seat & Details */}
                    <div className="p-6 space-y-5">
                        {/* Seats */}
                        {booking?.seats?.length > 0 && (
                            <div className="flex items-start gap-3">
                                <div className="w-8 h-8 rounded-lg bg-[#E50914]/10 flex items-center justify-center shrink-0">
                                    <Armchair size={16} className="text-[#E50914]" />
                                </div>
                                <div>
                                    <div className="text-gray-500 text-xs uppercase tracking-wider mb-1">Ghế đã đặt ({booking.seats.length} ghế)</div>
                                    <div className="flex flex-wrap gap-2">
                                        {booking.seats.map(seat => (
                                            <span
                                                key={seat}
                                                className="bg-[#E50914]/10 text-[#E50914] border border-[#E50914]/30 rounded-md px-2.5 py-0.5 text-sm font-bold font-mono"
                                            >
                                                {seat}
                                            </span>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* Services */}
                        {booking?.services?.filter(s => s.quantity > 0).length > 0 && (
                            <div className="flex items-start gap-3">
                                <div className="w-8 h-8 rounded-lg bg-yellow-500/10 flex items-center justify-center shrink-0">
                                    <Coffee size={16} className="text-yellow-500" />
                                </div>
                                <div className="flex-1">
                                    <div className="text-gray-500 text-xs uppercase tracking-wider mb-2">Dịch vụ đi kèm</div>
                                    <div className="space-y-1.5">
                                        {booking.services.filter(s => s.quantity > 0).map((s, idx) => (
                                            <div key={idx} className="flex justify-between items-center">
                                                <span className="text-white text-sm">
                                                    {s.serviceId?.name || 'Dịch vụ'} × {s.quantity}
                                                </span>
                                                <span className="text-gray-400 text-sm">
                                                    {((s.serviceId?.price || 0) * s.quantity).toLocaleString('vi-VN')}đ
                                                </span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* Voucher */}
                        {voucher && booking?.discountAmount > 0 && (
                            <div className="flex items-start gap-3">
                                <div className="w-8 h-8 rounded-lg bg-green-500/10 flex items-center justify-center shrink-0">
                                    <Tag size={16} className="text-green-500" />
                                </div>
                                <div className="flex-1">
                                    <div className="text-gray-500 text-xs uppercase tracking-wider mb-1">Mã giảm giá đã áp dụng</div>
                                    <div className="flex justify-between items-center">
                                        <span className="bg-green-500/10 text-green-400 border border-green-500/30 rounded-md px-2.5 py-0.5 text-sm font-bold font-mono">
                                            {voucher.code}
                                        </span>
                                        <span className="text-green-400 font-bold">
                                            - {booking.discountAmount.toLocaleString('vi-VN')}đ
                                        </span>
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* Payment Method */}
                        <div className="flex items-start gap-3">
                            <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center shrink-0">
                                <CreditCard size={16} className="text-blue-400" />
                            </div>
                            <div>
                                <div className="text-gray-500 text-xs uppercase tracking-wider mb-1">Phương thức thanh toán</div>
                                <span className="text-white text-sm font-medium">
                                    {payMethodLabel[booking?.paymentMethod] || booking?.paymentMethod}
                                </span>
                            </div>
                        </div>
                    </div>

                    {/* Dashed Divider (Ticket Tear Effect) */}
                    <div className="relative flex items-center px-6">
                        <div className="w-5 h-5 rounded-full bg-[#050505] absolute -left-3 border-r border-white/10"></div>
                        <div className="flex-1 border-t border-dashed border-white/15"></div>
                        <div className="w-5 h-5 rounded-full bg-[#050505] absolute -right-3 border-l border-white/10"></div>
                    </div>

                    {/* Price Summary */}
                    <div className="p-6 space-y-2">
                        <div className="flex justify-between text-sm text-gray-400">
                            <span>Tiền vé ({booking?.seats?.length || 0} ghế)</span>
                            <span>{(ticketPrice - serviceTotal).toLocaleString('vi-VN')}đ</span>
                        </div>
                        {serviceTotal > 0 && (
                            <div className="flex justify-between text-sm text-gray-400">
                                <span>Dịch vụ đi kèm</span>
                                <span>{serviceTotal.toLocaleString('vi-VN')}đ</span>
                            </div>
                        )}
                        {booking?.discountAmount > 0 && (
                            <div className="flex justify-between text-sm text-green-400">
                                <span>Giảm giá (Voucher)</span>
                                <span>- {booking.discountAmount.toLocaleString('vi-VN')}đ</span>
                            </div>
                        )}
                        <Divider className="border-white/10 my-3" />
                        <div className="flex justify-between items-center">
                            <span className="text-white font-bold text-lg">Tổng đã thanh toán</span>
                            <span className="text-[#E50914] font-black text-2xl">
                                {(booking?.totalPrice || 0).toLocaleString('vi-VN')}đ
                            </span>
                        </div>
                    </div>

                    {/* QR Code */}
                    {(booking?.status === 'Paid' || booking?.status === 'CheckedIn') && (
                        <div className="p-6 border-t border-white/5 bg-white flex flex-col items-center justify-center">
                            <QRCode value={booking._id} size={150} />
                            <p className="mt-3 text-black font-bold text-sm">Đưa mã này cho nhân viên soát vé</p>
                            {booking?.status === 'CheckedIn' && <p className="text-green-600 font-bold mt-1 uppercase">Đã soát vé</p>}
                        </div>
                    )}
                </div>

                {/* Actions */}
                <div className="mt-6 flex flex-wrap gap-3 justify-center">
                    {!hasReviewed && (
                        <Button 
                            type="primary" 
                            size="large" 
                            className="bg-yellow-500 hover:bg-yellow-600 border-none text-black font-bold"
                            onClick={() => setIsReviewModalOpen(true)}
                            icon={<Star size={18} />}
                        >
                            Đánh giá phim ngay
                        </Button>
                    )}
                    <Button size="large" onClick={() => navigate('/')}>
                        Về trang chủ
                    </Button>
                    <Button
                        type="primary"
                        size="large"
                        className="bg-[#E50914]"
                        onClick={() => navigate('/phim')}
                    >
                        Đặt vé tiếp
                    </Button>
                </div>
            </div>

            {/* Modal Đánh Giá */}
            <Modal
                title={`Đánh giá phim: ${movie?.title}`}
                open={isReviewModalOpen}
                onCancel={() => setIsReviewModalOpen(false)}
                footer={[
                    <Button key="back" onClick={() => setIsReviewModalOpen(false)}>
                        Hủy
                    </Button>,
                    <Button 
                        key="submit" 
                        type="primary" 
                        loading={submittingReview} 
                        onClick={handleSubmitReview}
                        className="bg-[#E50914] border-none hover:bg-red-700"
                    >
                        Gửi đánh giá
                    </Button>,
                ]}
            >
                <div className="py-4 space-y-4">
                    <div className="text-center">
                        <Rate value={reviewRating} onChange={setReviewRating} className="text-[#E50914] text-3xl" />
                    </div>
                    <Input.TextArea
                        value={reviewText}
                        onChange={(e) => setReviewText(e.target.value)}
                        placeholder="Bạn nghĩ gì về bộ phim này? (Cốt truyện, diễn xuất, kỹ xảo...)"
                        rows={4}
                    />
                </div>
            </Modal>
        </div>
    );
}
