const crypto = require('crypto');
const https = require('https');
const { VNPay, ignoreLogger, ProductCode, VnpLocale, dateFormat } = require('vnpay');
const Booking = require('../models/booking.model');
const Voucher = require('../models/voucher.model');
const Showtime = require('../models/showtime.model');
const { sendBookingConfirmationEmail } = require('./email.service');
const GiftService = require('./gift.service');
const UserService = require('./users.service');
const NotificationService = require('./notification.service');

// =========================================================
// Cấu hình Momo & VNPay (Sandbox / Test)
// =========================================================
const MOMO_CONFIG = {
    accessKey: 'F8BBA842ECF85',
    secretKey: 'K951B6PE1waDMi640xX08PD3vg6EkVlz',
    partnerCode: 'MOMO',
    hostname: 'test-payment.momo.vn',
};

const VNPAY_CONFIG = {
    tmnCode: 'DH2F13SW',
    secureSecret: '7VJPG70RGPOWFO47VSBT29WPDYND0EJG',
    vnpayHost: 'https://sandbox.vnpayment.vn',
    testMode: true,
    hashAlgorithm: 'SHA512',
    loggerFn: ignoreLogger,
};

// Client URL cho redirect sau thanh toán
const CLIENT_URL = process.env.URL_CLIENT || 'http://localhost:5173';
const SERVER_URL = process.env.URL_SERVER || 'http://localhost:3000';

function generatePayID() {
    const now = new Date();
    return `FLIX${now.getTime()}${now.getSeconds().toString().padStart(2, '0')}`;
}

class BookingPaymentService {

    /**
     * Tạo URL thanh toán Momo và lưu đơn vé với status='Pending'
     * @param {Object} bookingData - { showtimeId, seats, services, totalPrice, voucherId, discountAmount }
     * @param {String} userId
     */
    async createMomoPayment(bookingData, userId) {
        // 1. Tạo booking trước với status Pending (Chưa thanh toán)
        const booking = await this._createPendingBooking(bookingData, userId, 'Momo');

        return new Promise((resolve, reject) => {
            const { accessKey, secretKey, partnerCode, hostname } = MOMO_CONFIG;
            const orderId = `${partnerCode}${booking._id}`;
            const requestId = orderId;
            const orderInfo = `Dat ve xem phim FlixFlow - ${booking._id}`;
            const redirectUrl = `${CLIENT_URL}/booking/result`;
            const ipnUrl = `${SERVER_URL}/api/payment/momo/callback`;
            const requestType = 'payWithMethod';
            const amount = Math.round(bookingData.totalPrice);
            const extraData = Buffer.from(JSON.stringify({ bookingId: booking._id })).toString('base64');

            const rawSignature = `accessKey=${accessKey}&amount=${amount}&extraData=${extraData}&ipnUrl=${ipnUrl}&orderId=${orderId}&orderInfo=${orderInfo}&partnerCode=${partnerCode}&redirectUrl=${redirectUrl}&requestId=${requestId}&requestType=${requestType}`;
            const signature = crypto.createHmac('sha256', secretKey).update(rawSignature).digest('hex');

            const requestBody = JSON.stringify({
                partnerCode,
                partnerName: 'FlixFlow Cinema',
                storeId: 'FlixFlowStore',
                requestId,
                amount,
                orderId,
                orderInfo,
                redirectUrl,
                ipnUrl,
                lang: 'vi',
                requestType,
                autoCapture: true,
                extraData,
                orderGroupId: '',
                signature,
            });

            const options = {
                hostname,
                port: 443,
                path: '/v2/gateway/api/create',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(requestBody),
                },
            };

            const req = https.request(options, (res) => {
                let data = '';
                res.on('data', (chunk) => { data += chunk; });
                res.on('end', () => {
                    try {
                        const parsed = JSON.parse(data);
                        // Trả về URL redirect + bookingId để frontend redirect người dùng
                        resolve({ payUrl: parsed.payUrl, bookingId: booking._id });
                    } catch (err) {
                        reject(err);
                    }
                });
            });

            req.on('error', (e) => reject(e));
            req.write(requestBody);
            req.end();
        });
    }

    /**
     * Tạo URL thanh toán VNPay và lưu đơn vé với status='Pending'
     */
    async createVNPayPayment(bookingData, userId, ipAddr) {
        const booking = await this._createPendingBooking(bookingData, userId, 'VNPay');

        const vnpay = new VNPay(VNPAY_CONFIG);
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);

        const payUrl = await vnpay.buildPaymentUrl({
            vnp_Amount: Math.round(bookingData.totalPrice),
            vnp_IpAddr: ipAddr || '127.0.0.1',
            vnp_TxnRef: `FLIX_${booking._id}_${generatePayID()}`,
            vnp_OrderInfo: `Dat ve xem phim FlixFlow - ${booking._id}`,
            vnp_OrderType: ProductCode.Other,
            vnp_ReturnUrl: `${SERVER_URL}/api/payment/vnpay/callback`,
            vnp_Locale: VnpLocale.VN,
            vnp_CreateDate: dateFormat(new Date()),
            vnp_ExpireDate: dateFormat(tomorrow),
        });

        return { payUrl, bookingId: booking._id };
    }

    /**
     * Callback từ Momo sau khi thanh toán xong (IPN URL - server to server)
     */
    async momoCallback(query) {
        // resultCode = 0: Thành công
        if (query.resultCode === '0' || query.resultCode === 0) {
            return await this._confirmMomoSuccess(query);
        }
        // Thất bại: mở khóa ghế
        await this._releaseSeatsByMomoExtraData(query.extraData);
        throw new Error('Thanh toán Momo thất bại');
    }

    /**
     * Xác nhận kết quả khi user bị redirect về từ Momo (client gọi lên server)
     */
    async confirmMomoReturn(query) {
        if (query.resultCode === '0' || query.resultCode === 0) {
            return await this._confirmMomoSuccess(query);
        }
        // Thất bại: mở khóa ghế
        await this._releaseSeatsByMomoExtraData(query.extraData);
        throw new Error('Thanh toán Momo thất bại');
    }

    async _confirmMomoSuccess(query) {
        let bookingId = null;
        try {
            const extraData = JSON.parse(Buffer.from(query.extraData, 'base64').toString('utf8'));
            bookingId = extraData.bookingId;
        } catch (e) {
            throw new Error('Không thể đọc thông tin đơn hàng từ Momo');
        }

        const existing = await Booking.findById(bookingId);
        if (!existing) throw new Error('Không tìm thấy đơn hàng');
        if (existing.status === 'Paid') return existing;

        const booking = await Booking.findByIdAndUpdate(
            bookingId,
            { status: 'Paid', paymentTransactionId: query.transId },
            { new: true }
        );

        if (booking && booking.voucherId) {
            await Voucher.findByIdAndUpdate(booking.voucherId, { $inc: { usedCount: 1 } });
        }

        // Gửi email xác nhận (non-blocking)
        try {
            const fullBooking = await Booking.findById(booking._id)
                .populate({ path: 'showtimeId', populate: [{ path: 'movieId', select: 'title' }, { path: 'roomId', select: 'name', populate: { path: 'cinemaId', select: 'name' } }] })
                .populate('services.serviceId', 'name price')
                .populate('voucherId', 'code')
                .populate('userId', 'fullName email');
            sendBookingConfirmationEmail(fullBooking);
        } catch (_) {}

        // Tự động trao quà tặng nếu đủ điều kiện (non-blocking)
        GiftService.processGiftsForBooking(booking).catch(err =>
            console.error('[Gift] processGifts error (Momo):', err.message)
        );

        // Tự động cập nhật tổng tiền chi tiêu và hạng thành viên
        if (booking.userId) {
            UserService.addTotalSpentAndCheckTier(booking.userId, booking.totalPrice).catch(err =>
                console.error('[User] Update tier error (Momo):', err.message)
            );
        }

        // Gửi thông báo cho user
        if (booking.userId) {
            try {
                const populated = await Booking.findById(booking._id)
                    .populate({ path: 'showtimeId', populate: { path: 'movieId', select: 'title' } });
                const movieTitle = populated?.showtimeId?.movieId?.title || 'phim';
                NotificationService.notifyBookingSuccess(booking.userId, booking, movieTitle).catch(() => {});
            } catch (_) {}
        }

        return booking;
    }

    async vnpayCallback(query) {
        const vnpay = new VNPay(VNPAY_CONFIG);
        const isValid = vnpay.verifyReturnUrl(query);

        if (isValid && query.vnp_ResponseCode === '00') {
            return await this._confirmVNPaySuccess(query);
        }
        // Thất bại: mở khóa ghế
        await this._releaseSeatsByVNPayTxnRef(query.vnp_TxnRef);
        throw new Error('Thanh toán VNPay thất bại hoặc chữ ký không hợp lệ');
    }

    /**
     * Xác nhận kết quả khi client gọi lên sau redirect VNPay
     */
    async confirmVNPayReturn(query) {
        if (query.vnp_ResponseCode === '00') {
            return await this._confirmVNPaySuccess(query);
        }
        // Thất bại: mở khóa ghế
        await this._releaseSeatsByVNPayTxnRef(query.vnp_TxnRef);
        throw new Error('Thanh toán VNPay thất bại');
    }

    async _confirmVNPaySuccess(query) {
        const parts = query.vnp_TxnRef.split('_');
        const bookingId = parts[1];

        const existing = await Booking.findById(bookingId);
        if (!existing) throw new Error('Không tìm thấy đơn hàng');
        if (existing.status === 'Paid') return existing;

        const booking = await Booking.findByIdAndUpdate(
            bookingId,
            { status: 'Paid', paymentTransactionId: query.vnp_TransactionNo },
            { new: true }
        );

        if (booking && booking.voucherId) {
            await Voucher.findByIdAndUpdate(booking.voucherId, { $inc: { usedCount: 1 } });
        }

        // Gửi email xác nhận (non-blocking)
        try {
            const fullBooking = await Booking.findById(booking._id)
                .populate({ path: 'showtimeId', populate: [{ path: 'movieId', select: 'title' }, { path: 'roomId', select: 'name', populate: { path: 'cinemaId', select: 'name' } }] })
                .populate('services.serviceId', 'name price')
                .populate('voucherId', 'code')
                .populate('userId', 'fullName email');
            sendBookingConfirmationEmail(fullBooking);
        } catch (_) {}

        // Tự động trao quà tặng nếu đủ điều kiện (non-blocking)
        GiftService.processGiftsForBooking(booking).catch(err =>
            console.error('[Gift] processGifts error (VNPay):', err.message)
        );

        // Tự động cập nhật tổng tiền chi tiêu và hạng thành viên
        if (booking.userId) {
            UserService.addTotalSpentAndCheckTier(booking.userId, booking.totalPrice).catch(err =>
                console.error('[User] Update tier error (VNPay):', err.message)
            );
        }

        // Gửi thông báo cho user
        if (booking.userId) {
            try {
                const populated = await Booking.findById(booking._id)
                    .populate({ path: 'showtimeId', populate: { path: 'movieId', select: 'title' } });
                const movieTitle = populated?.showtimeId?.movieId?.title || 'phim';
                NotificationService.notifyBookingSuccess(booking.userId, booking, movieTitle).catch(() => {});
            } catch (_) {}
        }

        return booking;
    }

    async _createPendingBooking(bookingData, userId, paymentMethod) {
        const { showtimeId, seats, services, totalPrice, voucherId, discountAmount } = bookingData;

        // Kiểm tra ghế và khóa ghế
        const showtime = await Showtime.findById(showtimeId);
        if (!showtime) throw new Error('Suất chiếu không tồn tại');

        const unavailableSeats = showtime.seats.filter(seat => {
            const code = `${seat.row}${seat.number}`;
            return seats.includes(code) && seat.status !== 'Available';
        });

        if (unavailableSeats.length > 0) {
            const codes = unavailableSeats.map(s => `${s.row}${s.number}`).join(', ');
            throw new Error(`Ghế ${codes} đã có người đặt. Vui lòng chọn ghế khác!`);
        }

        // Khóa ghế
        showtime.seats.forEach(seat => {
            if (seats.includes(`${seat.row}${seat.number}`)) {
                seat.status = 'Booked';
                seat.userId = userId;
            }
        });
        await showtime.save();

        // Tạo booking
        const booking = await Booking.create({
            userId,
            showtimeId,
            seats,
            services: services || [],
            totalPrice,
            voucherId: voucherId || null,
            discountAmount: discountAmount || 0,
            paymentMethod,
            status: 'Pending',
        });

        return booking;
    }

    /**
     * PRIVATE: Mở khóa ghế khi thanh toán thất bại
     */
    async _releaseSeats(bookingId) {
        const booking = await Booking.findById(bookingId);
        if (!booking || booking.status === 'Paid') return; // Đã paid rồi thì không release

        // Đánh dấu booking là Cancelled
        booking.status = 'Cancelled';
        await booking.save();

        // Trả ghế về Available
        const showtime = await Showtime.findById(booking.showtimeId);
        if (showtime) {
            showtime.seats.forEach(seat => {
                if (booking.seats.includes(`${seat.row}${seat.number}`)) {
                    seat.status = 'Available';
                    seat.userId = null;
                }
            });
            await showtime.save();
        }
    }

    async _releaseSeatsByMomoExtraData(extraData) {
        try {
            const data = JSON.parse(Buffer.from(extraData, 'base64').toString('utf8'));
            if (data.bookingId) await this._releaseSeats(data.bookingId);
        } catch (_) {}
    }

    async _releaseSeatsByVNPayTxnRef(txnRef) {
        try {
            const parts = (txnRef || '').split('_');
            const bookingId = parts[1];
            if (bookingId) await this._releaseSeats(bookingId);
        } catch (_) {}
    }
}

module.exports = new BookingPaymentService();
